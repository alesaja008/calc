import Kalkulator from "@/src/components";
import "bootstrap/dist/css/bootstrap.min.css";

export default function Home() {
  return (
    <>
      <Kalkulator />
    </>
  );
}
